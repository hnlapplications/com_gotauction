<?php
defined("_JEXEC") or die();

class GotauctionTableHome extends JTable
{
	//no functionality necessary here
}
