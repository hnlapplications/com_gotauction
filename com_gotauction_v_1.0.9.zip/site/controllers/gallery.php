<?php
defined ('_JEXEC') or die();

class GotauctionControllerGallery extends JControllerForm
{
	function __construct()
	{
		parent::__construct();
	}
}

