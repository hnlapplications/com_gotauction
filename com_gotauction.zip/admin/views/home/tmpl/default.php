<?php

defined("_JEXEC") or die();
//$front_url=JRoute::_('index.php?option=com_gotauction');
?>

<h1><?php echo JText::_('COM_GOTAUCTION_WELCOME'); ?></h1>

<p>
	<?php echo JText::_('COM_GOTAUCTION_WELCOME_TEXT'); ?>
</p>
