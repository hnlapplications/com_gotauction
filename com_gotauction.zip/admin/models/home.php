<?php

defined ("_JEXEC") or die();

class GotauctionModelHome extends JModelList
{
	//no functionality necessary here
}
