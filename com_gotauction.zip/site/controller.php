<?php

defined ('_JEXEC') or die();

class GotauctionController extends JControllerLegacy
{
	function __construct()
	{
		parent::__construct();		
		//check view vs user permissions here
	}
}
