<?php
defined ('_JEXEC') or die();

class GotauctionControllerAuctions extends JControllerForm
{
	function __construct()
	{
		parent::__construct();
	}
}
