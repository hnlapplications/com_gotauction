<?php
defined ('_JEXEC') or die();

class GotauctionControllerAuctioneer extends JControllerForm
{
	function __construct()
	{
		parent::__construct();
	}
}