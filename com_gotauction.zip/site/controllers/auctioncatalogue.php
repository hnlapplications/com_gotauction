<?php
defined ('_JEXEC') or die();

class GotauctionControllerAuctioncatalogue extends JControllerForm
{
	function __construct()
	{
		$this->view_list="auctions";
		parent::__construct();
	}
}

