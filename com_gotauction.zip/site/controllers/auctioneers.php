<?php
defined ('_JEXEC') or die();

class GotauctionControllerAuctioneers extends JControllerForm
{
	function __construct()
	{
		parent::__construct();
	}
}
