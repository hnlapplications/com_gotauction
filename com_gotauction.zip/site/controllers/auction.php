<?php
defined ('_JEXEC') or die();

class GotauctionControllerAuction extends JControllerForm
{
	function __construct()
	{
		parent::__construct();
	}
}

