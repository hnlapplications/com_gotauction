<?php
defined ('_JEXEC') or die();

class GotauctionControllerLot extends JControllerForm
{
	function __construct()
	{
		parent::__construct();
	}
}

